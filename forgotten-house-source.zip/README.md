# The Forgotten House
A browser-based text adventure / dungeon crawler built with React + Tailwind CSS.

## Structure
- `src/pages/Home.jsx` — Main game page & state management
- `src/lib/gameData.js` — Room definitions & initial state
- `src/lib/combatData.js` — Enemy definitions & combat math
- `src/lib/parasiteData.js` — Parasite stages & cutscene data
- `src/components/game/` — All game UI components

## Tech Stack
React 18, Tailwind CSS, shadcn/ui, Lucide icons, Vite

## Getting Started
```
npm install
npm run dev
```

import { useState, useCallback, useMemo, useEffect } from 'react';
import { ROOMS, INITIAL_STATE } from '../lib/gameData';
import { ENEMIES, calcPlayerDamage, calcEnemyDamage } from '../lib/combatData';
import { PARASITE_STAGES, PARASITE_CUTSCENES } from '../lib/parasiteData';
import RoomMap from '../components/game/RoomMap';
import HealthBar from '../components/game/HealthBar';
import StoryPanel from '../components/game/StoryPanel';
import CharacterDisplay from '../components/game/CharacterDisplay';
import CutsceneOverlay from '../components/game/CutsceneOverlay';
import DownloadGameFiles from '../components/game/DownloadGameFiles';

const SAVE_KEY = 'forgotten_house_save';

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

const DEFAULT_STATE = { ...INITIAL_STATE, log: [], parasiteStage: 'none' };

export default function Home() {
  const [gameState, setGameState] = useState(() => loadSave() || DEFAULT_STATE);
  const [activeCutscene, setActiveCutscene] = useState(null);
  const [pendingStateAfterCutscene, setPendingStateAfterCutscene] = useState(null);

  useEffect(() => {
    localStorage.setItem(SAVE_KEY, JSON.stringify(gameState));
  }, [gameState]);

  const visitedRooms = useMemo(() => {
    const set = new Set([gameState.currentRoom]);
    gameState.log.forEach(e => e.room && set.add(e.room));
    return set;
  }, [gameState.currentRoom, gameState.log]);

  // Apply parasite drain before resolving a new state
  function applyParasiteDrain(state) {
    const stage = PARASITE_STAGES[state.parasiteStage || 'none'];
    if (!stage || stage.hpDrainPerAction === 0) return state;
    const newHp = Math.max(0, state.health - stage.hpDrainPerAction);
    const log = newHp < state.health
      ? [...state.log, { text: `🪱 The parasite drains ${stage.hpDrainPerAction} HP. ${stage.description}`, type: 'damage', room: state.currentRoom }]
      : state.log;
    return { ...state, health: newHp, log, gameOver: newHp <= 0, won: false };
  }

  const handleGoto = useCallback((roomId) => {
    setGameState(prev => {
      const next = {
        ...prev,
        currentRoom: roomId,
        log: [],
        combatState: null,
        characterState: { ...prev.characterState, mood: 'neutral' },
      };
      return applyParasiteDrain(next);
    });
  }, []);

  const handleAction = useCallback((roomId, eventIndex) => {
    setGameState(prev => {
      const event = ROOMS[roomId].events[eventIndex];

      // Start combat
      if (event.combat) {
        const enemy = ENEMIES[event.combat];
        return applyParasiteDrain({
          ...prev,
          combatState: {
            enemyId: event.combat,
            enemyHp: enemy.maxHp,
            maxEnemyHp: enemy.maxHp,
            isDefending: false,
            log: [{ text: `⚔️ A ${enemy.name} appears!`, type: 'info' }],
          },
          characterState: { mood: 'scared' },
        });
      }

      if (!event.outcomes) return prev;
      const outcome = event.outcomes[0];
      const hasCondition = outcome.conditionFlag && prev.flags[outcome.conditionFlag];
      const text = hasCondition ? outcome.conditionText : outcome.text;
      const hpChange = hasCondition ? (outcome.conditionHealth ?? outcome.healthChange) : outcome.healthChange;
      const isWin = hasCondition ? outcome.conditionWin : outcome.winCheck;
      const mood = hasCondition ? (outcome.conditionMood || outcome.mood) : (outcome.mood || 'neutral');

      const newFlags = { ...prev.flags };
      if (outcome.flag) newFlags[outcome.flag] = true;

      let nextState = {
        ...prev,
        health: Math.min(prev.maxHealth, Math.max(0, prev.health + hpChange)),
        flags: newFlags,
        log: [...prev.log, { text, type: hpChange < 0 ? 'damage' : hpChange > 0 ? 'heal' : 'info', room: roomId, image: event.image || null }],
        gameOver: Math.max(0, prev.health + hpChange) <= 0 || isWin,
        won: !!isWin,
        characterState: { mood },
      };

      // Parasite event?
      if (event.parasite) {
        const cutscene = PARASITE_CUTSCENES[event.parasite];
        if (cutscene) {
          // Determine new stage (only escalate, never lower via infection)
          const stages = ['none', 'infected', 'advanced', 'critical'];
          const currentIdx = stages.indexOf(prev.parasiteStage || 'none');
          const newIdx = stages.indexOf(cutscene.stage);
          const resolvedStage = newIdx > currentIdx ? cutscene.stage : prev.parasiteStage;
          nextState = applyParasiteDrain({ ...nextState, parasiteStage: resolvedStage });
          setPendingStateAfterCutscene(nextState);
          setActiveCutscene(cutscene);
          return prev; // hold state until cutscene closes
        }
      }

      return applyParasiteDrain(nextState);
    });
  }, []);

  const handleCombatAction = useCallback((action) => {
    setGameState(prev => {
      if (!prev.combatState) return prev;
      const { combatState, flags } = prev;
      const enemy = ENEMIES[combatState.enemyId];
      let { enemyHp, isDefending } = combatState;
      let playerHp = prev.health;
      const combatLog = [...combatState.log];
      let newFlags = { ...flags };
      let playerMood = 'neutral';

      if (action === 'attack') {
        const dmg = calcPlayerDamage(flags);
        const actualDmg = Math.max(0, dmg - enemy.defense);
        enemyHp = Math.max(0, enemyHp - actualDmg);
        combatLog.push({ text: `⚔️ You attack for ${actualDmg} damage! (${enemyHp}/${combatState.maxEnemyHp} HP left)`, type: 'player' });
      } else if (action === 'defend') {
        isDefending = true;
        combatLog.push({ text: `🛡️ You brace for the next attack, reducing incoming damage.`, type: 'player' });
      } else if (action === 'item') {
        // Cure parasite if herbs available
        if (flags.has_herbs && prev.parasiteStage !== 'none') {
          newFlags = { ...newFlags, has_herbs: false };
          const cutscene = PARASITE_CUTSCENES['cured'];
          const nextState = applyParasiteDrain({
            ...prev,
            flags: newFlags,
            parasiteStage: 'none',
            combatState: { ...combatState, isDefending: false, log: [...combatLog, { text: '🌿 You consumed the herbs. The parasite retreats!', type: 'player' }] },
          });
          setPendingStateAfterCutscene(nextState);
          setActiveCutscene(cutscene);
          return prev;
        }
        const healAmt = flags.has_herbs ? 20 : 15;
        const consumed = flags.has_herbs ? 'has_herbs' : null;
        if (consumed) newFlags = { ...newFlags, [consumed]: false };
        playerHp = Math.min(prev.maxHealth, playerHp + healAmt);
        combatLog.push({ text: `💊 You use your supplies and recover ${healAmt} HP!`, type: 'player' });
      }

      // Enemy dead?
      if (enemyHp <= 0) {
        const reward = enemy.reward;
        if (reward.flag) newFlags[reward.flag] = true;
        const newHp = Math.min(prev.maxHealth, playerHp + (reward.healthReward || 0));
        return applyParasiteDrain({
          ...prev,
          health: newHp,
          flags: newFlags,
          combatState: null,
          characterState: { mood: 'happy' },
          gameOver: !!reward.winCheck,
          won: !!reward.winCheck,
          log: [...prev.log, { text: `🏆 ${reward.text}`, type: 'heal', room: prev.currentRoom }],
        });
      }

      // Enemy attacks back
      const enemyDmg = calcEnemyDamage(enemy.attack, isDefending);
      playerHp = Math.max(0, playerHp - enemyDmg);
      playerMood = playerHp < 30 ? 'hurt' : 'neutral';
      combatLog.push({ text: `💥 ${enemy.name} hits you for ${enemyDmg} damage! (${playerHp}/${prev.maxHealth} HP)`, type: 'enemy' });

      return applyParasiteDrain({
        ...prev,
        health: playerHp,
        flags: newFlags,
        characterState: { mood: playerMood },
        gameOver: playerHp <= 0,
        won: false,
        combatState: { ...combatState, enemyHp, isDefending: false, log: combatLog },
      });
    });
  }, []);

  const handleCutsceneClose = useCallback(() => {
    setActiveCutscene(null);
    if (pendingStateAfterCutscene) {
      setGameState(pendingStateAfterCutscene);
      setPendingStateAfterCutscene(null);
    }
  }, [pendingStateAfterCutscene]);

  const handleRestart = useCallback(() => {
    localStorage.removeItem(SAVE_KEY);
    setGameState(DEFAULT_STATE);
  }, []);

  return (
    <div className="min-h-screen bg-background p-3 md:p-4">
      <CutsceneOverlay cutscene={activeCutscene} onClose={handleCutsceneClose} />
      <header className="text-center mb-3 md:mb-4">
        <h1 className="text-2xl md:text-3xl font-bold text-primary tracking-tight">The Forgotten House</h1>
        <p className="text-xs text-muted-foreground mt-1">A dungeon crawl adventure</p>
        <div className="mt-2"><DownloadGameFiles /></div>
      </header>
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-[200px_1fr_220px] gap-4" style={{ minHeight: 'calc(100vh - 130px)' }}>
        {/* Left: Character + status */}
        <div className="flex flex-col gap-3">
          <CharacterDisplay
            characterState={gameState.characterState}
            combatState={gameState.combatState}
            parasiteStage={gameState.parasiteStage}
          />
          <HealthBar health={gameState.health} maxHealth={gameState.maxHealth} />
          <div className="bg-card border border-border rounded-lg p-3">
            <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2">Inventory</h3>
            <div className="text-xs text-muted-foreground space-y-1">
              {!gameState.flags.has_key && !gameState.flags.has_map && !gameState.flags.read_tome && !gameState.flags.knows_trap && !gameState.flags.has_herbs && !gameState.flags.has_sword && <p className="italic">Empty</p>}
              {gameState.flags.has_key && <p>🗝️ Rusty Key</p>}
              {gameState.flags.has_map && <p>🗺️ Map Fragment</p>}
              {gameState.flags.read_tome && <p>📖 Healing Knowledge</p>}
              {gameState.flags.knows_trap && <p>⚠️ Trap Warning</p>}
              {gameState.flags.has_herbs && <p>🌿 Healing Herbs (cures parasite)</p>}
              {gameState.flags.has_sword && <p>⚔️ Shortsword (+8 dmg)</p>}
            </div>
          </div>
        </div>

        {/* Center: Story / Combat */}
        <StoryPanel
          gameState={gameState}
          onAction={handleAction}
          onGoto={handleGoto}
          onRestart={handleRestart}
          onCombatAction={handleCombatAction}
        />

        {/* Right: Map */}
        <div style={{ minHeight: '300px' }}>
          <RoomMap currentRoom={gameState.currentRoom} visitedRooms={visitedRooms} />
        </div>
      </div>
    </div>
  );
}
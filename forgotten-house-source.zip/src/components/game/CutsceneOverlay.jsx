import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

export default function CutsceneOverlay({ cutscene, onClose }) {
  const [lineIndex, setLineIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [textVisible, setTextVisible] = useState(false);

  useEffect(() => {
    if (!cutscene) return;
    setLineIndex(0);
    setTextVisible(false);
    const t1 = setTimeout(() => setVisible(true), 50);
    const t2 = setTimeout(() => setTextVisible(true), 400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [cutscene]);

  if (!cutscene) return null;

  const isLast = lineIndex >= cutscene.lines.length - 1;

  function handleNext() {
    if (!isLast) {
      setTextVisible(false);
      setTimeout(() => {
        setLineIndex(i => i + 1);
        setTextVisible(true);
      }, 300);
    } else {
      setVisible(false);
      setTimeout(onClose, 500);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center transition-opacity duration-500"
      style={{ opacity: visible ? 1 : 0, background: 'rgba(0,0,0,0.92)' }}
    >
      {/* Tinted vignette */}
      <div
        className="absolute inset-0 pointer-events-none transition-all duration-1000"
        style={{ background: cutscene.imageTint }}
      />

      {/* Scanline effect */}
      <div
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.5) 2px, rgba(0,0,0,0.5) 4px)' }}
      />

      <div className="relative z-10 max-w-xl w-full mx-6 flex flex-col items-center gap-6 text-center">
        {/* Title */}
        <div className="space-y-1">
          <p className="text-xs uppercase tracking-[0.3em] text-green-400/70 font-mono">— cutscene —</p>
          <h2 className="text-2xl md:text-3xl font-bold text-white/90 tracking-tight">{cutscene.title}</h2>
        </div>

        {/* Progress dots */}
        <div className="flex gap-2">
          {cutscene.lines.map((_, i) => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full transition-all duration-300"
              style={{ background: i <= lineIndex ? 'rgba(74,222,128,0.9)' : 'rgba(255,255,255,0.2)' }}
            />
          ))}
        </div>

        {/* Line text */}
        <div
          className="min-h-[80px] flex items-center transition-opacity duration-300"
          style={{ opacity: textVisible ? 1 : 0 }}
        >
          <p className="text-lg md:text-xl text-white/80 italic leading-relaxed font-serif">
            "{cutscene.lines[lineIndex]}"
          </p>
        </div>

        <Button
          onClick={handleNext}
          className="bg-green-900/60 hover:bg-green-800/80 border border-green-500/30 text-green-200 px-8"
        >
          {isLast ? 'Continue' : 'Next →'}
        </Button>
      </div>
    </div>
  );
}
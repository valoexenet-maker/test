import { Heart } from 'lucide-react';

export default function HealthBar({ health, maxHealth }) {
  const pct = Math.max(0, Math.min(100, (health / maxHealth) * 100));
  const color = pct > 60 ? 'bg-green-500' : pct > 30 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center gap-2 mb-2">
        <Heart className="w-4 h-4 text-red-400" />
        <span className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Health</span>
        <span className="ml-auto text-sm font-bold text-foreground">{health}/{maxHealth}</span>
      </div>
      <div className="h-3 bg-muted rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all duration-500 ease-out`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
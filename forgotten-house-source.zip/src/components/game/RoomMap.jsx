import { ROOMS } from '../../lib/gameData';

const GRID = { cols: 3, rows: 4 };

export default function RoomMap({ currentRoom, visitedRooms }) {
  const cells = [];
  for (let y = 0; y < GRID.rows; y++) {
    for (let x = 0; x < GRID.cols; x++) {
      const roomEntry = Object.entries(ROOMS).find(([, r]) => r.x === x && r.y === y);
      cells.push({ x, y, roomId: roomEntry?.[0], room: roomEntry?.[1] });
    }
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4 h-full flex flex-col">
      <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-3 font-semibold">Dungeon Map</h2>
      <div className="grid grid-cols-3 gap-1.5 flex-1">
        {cells.map((cell, i) => {
          if (!cell.roomId) return <div key={i} className="rounded bg-background/30" />;
          const isCurrent = cell.roomId === currentRoom;
          const visited = visitedRooms?.has(cell.roomId);
          return (
            <div
              key={i}
              className={`rounded flex items-center justify-center text-center p-1.5 text-[10px] leading-tight font-medium transition-all duration-300 ${
                isCurrent
                  ? 'bg-primary text-primary-foreground ring-2 ring-primary/50 shadow-lg shadow-primary/20'
                  : visited
                  ? 'bg-secondary text-secondary-foreground'
                  : 'bg-muted/50 text-muted-foreground'
              }`}
            >
              {visited || isCurrent ? cell.room.name : '???'}
            </div>
          );
        })}
      </div>
    </div>
  );
}
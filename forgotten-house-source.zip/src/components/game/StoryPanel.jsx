import { useRef, useEffect } from 'react';
import CombatPanel from './CombatPanel';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ROOMS } from '../../lib/gameData';

export default function StoryPanel({ gameState, onAction, onGoto, onRestart, onCombatAction }) {
  const bottomRef = useRef(null);
  const room = ROOMS[gameState.currentRoom];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [gameState.log.length]);

  if (gameState.gameOver) {
    return (
      <div className="bg-card border border-border rounded-lg p-6 h-full flex flex-col items-center justify-center text-center gap-4">
        <h2 className={`text-2xl font-bold ${gameState.won ? 'text-primary' : 'text-destructive'}`}>
          {gameState.won ? '🏆 Victory!' : '💀 You Died'}
        </h2>
        <p className="text-muted-foreground max-w-md">
          {gameState.won
            ? 'You claimed the treasure of the forgotten house. Songs will be sung of your bravery.'
            : 'The dungeon claims another soul. Perhaps next time you will fare better.'}
        </p>
        <Button onClick={onRestart} className="mt-2">Play Again</Button>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      <div className="border-b border-border px-5 py-3">
        <h2 className="text-lg font-bold text-foreground">{room.name}</h2>
      </div>
      <ScrollArea className="flex-1 px-5 py-4">
        <p className="text-sm leading-relaxed text-foreground/85 mb-4">{room.description}</p>
        {gameState.log.map((entry, i) => (
          <div key={i}>
            {entry.image && (
              <img src={entry.image} alt="scene" className="w-full rounded-lg mb-2 object-cover max-h-40" />
            )}
            <p className={`text-sm mb-2 pl-3 border-l-2 ${
              entry.type === 'damage' ? 'border-red-500/50 text-red-300/80' :
              entry.type === 'heal' ? 'border-green-500/50 text-green-300/80' :
              'border-primary/30 text-muted-foreground'
            }`}>
              {entry.text}
            </p>
          </div>
        ))}
        <div ref={bottomRef} />
      </ScrollArea>
      {gameState.combatState ? (
        <CombatPanel
          combatState={gameState.combatState}
          flags={gameState.flags}
          onCombatAction={onCombatAction}
          gameOver={gameState.gameOver}
        />
      ) : (
        <div className="border-t border-border p-4 space-y-2">
          {room.events.map((event, i) => (
            <Button
              key={i}
              variant="outline"
              className="w-full justify-start text-left h-auto py-2.5 px-4 text-sm"
              onClick={() => event.goto ? onGoto(event.goto) : event.combat ? onAction(gameState.currentRoom, i) : onAction(gameState.currentRoom, i)}
            >
              {event.text}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}
import { Button } from '@/components/ui/button';
import { Sword, Shield, FlaskConical, Skull } from 'lucide-react';
import { ENEMIES } from '../../lib/combatData';

export default function CombatPanel({ combatState, flags, onCombatAction, gameOver }) {
  if (!combatState || gameOver) return null;
  const enemy = ENEMIES[combatState.enemyId];
  const canUseItem = flags?.has_herbs || flags?.read_tome;

  return (
    <div className="border-t border-border p-4 space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <Skull className="w-4 h-4 text-red-400" />
        <p className="text-xs font-semibold text-red-400 uppercase tracking-wide">Combat — {enemy?.name}</p>
      </div>

      {/* Combat log */}
      <div className="bg-background/60 rounded-md p-2 max-h-24 overflow-y-auto space-y-1">
        {combatState.log.map((entry, i) => (
          <p key={i} className={`text-xs ${entry.type === 'player' ? 'text-blue-300' : entry.type === 'enemy' ? 'text-red-300' : 'text-muted-foreground'}`}>
            {entry.text}
          </p>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <Button
          variant="outline"
          className="flex flex-col gap-1 h-auto py-3 border-red-500/30 hover:border-red-500/60 hover:bg-red-500/10 text-red-300"
          onClick={() => onCombatAction('attack')}
        >
          <Sword className="w-4 h-4" />
          <span className="text-xs">Attack</span>
        </Button>
        <Button
          variant="outline"
          className={`flex flex-col gap-1 h-auto py-3 border-blue-500/30 hover:border-blue-500/60 hover:bg-blue-500/10 text-blue-300 ${combatState.isDefending ? 'bg-blue-500/20 border-blue-500/60' : ''}`}
          onClick={() => onCombatAction('defend')}
        >
          <Shield className="w-4 h-4" />
          <span className="text-xs">Defend</span>
        </Button>
        <Button
          variant="outline"
          disabled={!canUseItem}
          className="flex flex-col gap-1 h-auto py-3 border-green-500/30 hover:border-green-500/60 hover:bg-green-500/10 text-green-300 disabled:opacity-30"
          onClick={() => onCombatAction('item')}
        >
          <FlaskConical className="w-4 h-4" />
          <span className="text-xs">Use Item</span>
        </Button>
      </div>
    </div>
  );
}
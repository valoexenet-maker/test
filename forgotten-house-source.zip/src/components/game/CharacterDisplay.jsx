import EnemyStatus from './EnemyStatus';
import { PARASITE_STAGES } from '../../lib/parasiteData';

export default function CharacterDisplay({ characterState, combatState, parasiteStage }) {
  const parasiteInfo = PARASITE_STAGES[parasiteStage || 'none'];
  const BASE_IMAGE = 'https://media.base44.com/images/public/6a122f30fa4df05f87008a6a/c6b4db97a_generated_image.png';
  const image = characterState?.overrideImage || BASE_IMAGE;
  const mood = characterState?.mood || 'neutral';

  const moodLabel = {
    neutral: 'Ready',
    hurt: 'Injured',
    happy: 'Victorious',
    scared: 'Frightened',
  }[mood] || 'Ready';

  const moodColor = {
    neutral: 'text-primary',
    hurt: 'text-red-400',
    happy: 'text-green-400',
    scared: 'text-yellow-400',
  }[mood] || 'text-primary';

  const parasiteFilter = parasiteStage === 'critical'
    ? 'hue-rotate(90deg) saturate(2) brightness(0.7)'
    : parasiteStage === 'advanced'
    ? 'hue-rotate(80deg) saturate(1.6) brightness(0.85)'
    : parasiteStage === 'infected'
    ? 'hue-rotate(60deg) saturate(1.2)'
    : null;

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden flex flex-col">
      <div className="px-3 pt-3 pb-1 flex items-center justify-between">
        <h2 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Character</h2>
        <span className={`text-xs font-semibold ${moodColor}`}>{moodLabel}</span>
      </div>
      <div className="relative w-full" style={{ aspectRatio: '3/4' }}>
        <img
          src={image}
          alt="Player character"
          className="w-full h-full object-cover object-top transition-all duration-500"
          style={{ filter: parasiteFilter || (mood === 'hurt' ? 'hue-rotate(340deg) saturate(1.3)' : mood === 'happy' ? 'brightness(1.1)' : 'none') }}
        />
        {parasiteStage && parasiteStage !== 'none' && (
          <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,80,0,0.4) 100%)' }} />
        )}
        {mood === 'hurt' && (
          <div className="absolute inset-0 bg-red-900/20 pointer-events-none transition-all duration-500" />
        )}
      </div>
      {parasiteInfo?.label && (
        <div className="px-2 pb-1">
          <div className="bg-green-950/60 border border-green-700/40 rounded px-2 py-1 flex items-center gap-1.5">
            <span className="text-sm">🪱</span>
            <span className={`text-[10px] font-semibold ${parasiteInfo.color}`}>{parasiteInfo.label}</span>
            <span className="text-[9px] text-muted-foreground ml-auto">-{parasiteInfo.hpDrainPerAction} HP/action</span>
          </div>
        </div>
      )}
      {combatState && (
        <div className="p-2">
          <EnemyStatus combatState={combatState} />
        </div>
      )}
    </div>
  );
}
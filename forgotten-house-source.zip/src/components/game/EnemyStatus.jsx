import { ENEMIES } from '../../lib/combatData';
import { Skull } from 'lucide-react';

export default function EnemyStatus({ combatState }) {
  if (!combatState) return null;
  const enemy = ENEMIES[combatState.enemyId];
  if (!enemy) return null;
  const pct = Math.max(0, (combatState.enemyHp / combatState.maxEnemyHp) * 100);
  const barColor = pct > 60 ? 'bg-green-500' : pct > 30 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="bg-card border border-border rounded-lg p-3 animate-in slide-in-from-top-2 duration-300">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-lg">{enemy.emoji}</span>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-bold text-foreground truncate">{enemy.name}</p>
          <p className="text-[10px] text-muted-foreground">{combatState.enemyHp}/{combatState.maxEnemyHp} HP</p>
        </div>
        <Skull className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className="h-2.5 bg-muted rounded-full overflow-hidden">
        <div className={`h-full ${barColor} rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}